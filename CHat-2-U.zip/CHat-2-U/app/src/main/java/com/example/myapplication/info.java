package com.example.myapplication;

public class info {
    private String user,email,dp,id;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDp() {
        return dp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setDp(String dp) {
        this.dp = dp;
    }

    info(){}

    info(String u, String em, String img,String il){
        user=u; email=em; dp=img; id=il;
    }
}
