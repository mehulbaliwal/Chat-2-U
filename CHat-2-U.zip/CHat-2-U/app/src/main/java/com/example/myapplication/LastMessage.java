package com.example.myapplication;

public class LastMessage{
    private String user;
    private String msg;
    private long time;

    public LastMessage(){}
    public LastMessage(String user,String msg,long time){
        this.user=user; this.msg=msg; this.time=time;
    }

    public long getTime() {
        return time;
    }

    public String getMsg() {
        return msg;
    }

    public String getUser() {
        return user;
    }
}
