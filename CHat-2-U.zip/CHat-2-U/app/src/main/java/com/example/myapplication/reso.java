package com.example.myapplication;

import java.util.ArrayList;

public class reso {
    private static reso mInstance=null;
    public int var;
    public String user;
    public ArrayList<String> allservers;
    protected reso(){allservers=new ArrayList<String>();}
    public static synchronized reso getInstance(){
        if(mInstance==null){
            mInstance=new reso();
        }
        return mInstance;
    }

    public void reset(){
        this.var=-3;
        this.user=null;
        this.allservers=null;
    }
}
