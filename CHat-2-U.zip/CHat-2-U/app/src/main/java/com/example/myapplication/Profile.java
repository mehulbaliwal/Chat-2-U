package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;


public class Profile extends AppCompatActivity {
    de.hdodenhof.circleimageview.CircleImageView BSelectImage;
    de.hdodenhof.circleimageview.CircleImageView IVPreviewImage;
    int SELECT_PICTURE = 200;
    String user,uid;
    StorageReference sdf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        user=getIntent().getStringExtra("user");
        uid=getIntent().getStringExtra("id");

        FirebaseStorage sd= FirebaseStorage.getInstance();
        sdf=sd.getReference();
        // register the UI widgets with their appropriate IDs
        BSelectImage = findViewById(R.id.IVPreviewImage);
        IVPreviewImage = findViewById(R.id.IVPreviewImage);

        DatabaseReference db=FirebaseDatabase.getInstance().getReference().child("Users").child(uid);

        db.child("dp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Glide.with(getApplicationContext()).load(snapshot.getValue()).into(IVPreviewImage);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        TextView txt=findViewById(R.id.textView3);
        txt.setText(user);
        Button logout=findViewById(R.id.imb32);

        if(!user.equals(Usersclass.getInstance().accinfo.getDisplayName())){
            logout.setVisibility(View.GONE);
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        // handle the Choose Image button to trigger
        // the image chooser function
        BSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(user.equals(Usersclass.getInstance().accinfo.getDisplayName())){
                    imageChooser();
                }
            }
        });
    }


    // this function is triggered when
    // the Select Image Button is clicked
    void imageChooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(i, "Select Picture"), SELECT_PICTURE);
    }


    // this function is triggered when user
    // selects the image from the imageChooser
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {

            // compare the resultCode with the
            // SELECT_PICTURE constant
            if (requestCode == SELECT_PICTURE) {
                // Get the url of the image from data
                Uri selectedImageUri = data.getData();
                //Toast.makeText(Profile.this,selectedImageUri.toString(),Toast.LENGTH_LONG).show();
                if (null != selectedImageUri) {
                    // update the preview image in the layout
                    File img=new File(selectedImageUri.getPath());
                    try {
                        Bitmap cimg= MediaStore.Images.Media.getBitmap(this.getContentResolver(),selectedImageUri);
                        cimg=reducesize(cimg,65536);
                        ByteArrayOutputStream baos=new ByteArrayOutputStream();
                        cimg.compress(Bitmap.CompressFormat.JPEG,50,baos);
                        byte[] fimg=baos.toByteArray();
                        upload(selectedImageUri,fimg);

                    } catch (Exception e){
                        Toast.makeText(Profile.this,e.toString(),Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    private String getfx(Uri url){
        ContentResolver cr=getContentResolver();
        MimeTypeMap mime= MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(url));
    }

    private void upload(Uri selectedImageUri,byte[] fimg){
        StorageReference ref1 = sdf.child(user+".jpg");
        UploadTask uploadTask=ref1.putBytes(fimg);
        uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(Profile.this,"Uploaded Successfully",Toast.LENGTH_LONG).show();

               ref1.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                  @Override
                    public void onSuccess(Uri uri) {
                        update(user,uri.toString());
                        IVPreviewImage.setImageURI(selectedImageUri);
                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                Toast.makeText(Profile.this,"Upload on Progress",Toast.LENGTH_LONG).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Profile.this,e.toString(),Toast.LENGTH_LONG).show();
            }
        });

    }

    private Bitmap reducesize(Bitmap bitmap,int MAX_SIZE){
        double ratioSquare;
        int bitmapHeight,bitmapWidth;
        bitmapHeight=bitmap.getHeight();
        bitmapWidth=bitmap.getWidth();
        ratioSquare=(bitmapHeight*bitmapWidth)/MAX_SIZE;
        if(ratioSquare<=1){
            return bitmap;
        }
        double ratio=Math.sqrt(ratioSquare);
        int rH= (int) Math.round(bitmapHeight/ratio);
        int rW= (int) Math.round(bitmapWidth/ratio);
        return Bitmap.createScaledBitmap(bitmap,rH,rW,true);
    }

    private void update(String user,String link){
        reso.getInstance().var=6;
        ValueEventListener db55=FirebaseDatabase.getInstance()
                .getReference("Users")
                .orderByChild("user").equalTo(user)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot s:snapshot.getChildren()){
                            if(reso.getInstance().var==6) {
                                imgupload im = new imgupload(Usersclass.getInstance().servers.get(user),user, link);
                                FirebaseDatabase.getInstance()
                                        .getReference("Users")
                                        .child(s.getKey()).setValue(im);
                            }
                        }
                        reso.getInstance().var=26;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    private void adding(String user,String link){
        fbdatabase fb=new fbdatabase("Users");
        imgupload im=new imgupload(Usersclass.getInstance().servers.get(user),user, link);
        fb.adduserdata(im).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Toast.makeText(Profile.this,"Database uploaded",Toast.LENGTH_LONG).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Profile.this,"Database upload failed",Toast.LENGTH_LONG).show();
            }
        });
    }
}