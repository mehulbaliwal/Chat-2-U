package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class listall extends AppCompatActivity {
    LinearLayout lay;
    HashMap<String,LinearLayout> mp;
    ArrayList<info> mp1;
    String user;
    String userid,useremail,userdp;

    int width,height;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listall);
        lay=findViewById(R.id.ghjk);
        mp=new HashMap<String,LinearLayout>();
        mp1=new ArrayList<info>();
        user=Usersclass.getInstance().accinfo.getDisplayName();
        userid=Usersclass.getInstance().accinfo.getId();
        useremail=Usersclass.getInstance().accinfo.getEmail();
        userdp="https://firebasestorage.googleapis.com/v0/b/chat-tu-581bd.appspot.com/o/images.png?alt=media&token=ad37a662-68a7-4bd2-bf44-119d97e7eca3";
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;

        FirebaseDatabase.getInstance().getReference().child("Information").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s : snapshot.getChildren()){
                     info x=s.getValue(info.class);
                     if(mp.containsKey(x.getUser())==true || x.getId().equals(userid)){
                         continue;
                     }
                     LinearLayout kl=add(x,1);
                     mp.put(x.getUser(),kl);
                     TextView space = new TextView(getApplicationContext());
                     space.setText("");
                     space.setTextSize(20);
                     space.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                     lay.addView(kl);
                     lay.addView(space);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        ImageButton btn=findViewById(R.id.imageButton);
        EditText tst=findViewById(R.id.editTextTextPersonName);

        tst.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                   String kl=s.toString();

                   for(String ki : mp.keySet()){
                       boolean match=true;
                       for(int i=0;i<kl.length();i++){
                           if(kl.charAt(i)!=ki.charAt(i)){
                               match=false;
                               break;
                           }
                       }

                       if(match){
                           mp.get(ki).setVisibility(View.VISIBLE);
                       }else{
                           mp.get(ki).setVisibility(View.GONE);
                       }
                   }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public LinearLayout add(info jkl,int al){
        //msg
        TextView valueTV = new TextView(this);
        valueTV.setText(jkl.getEmail());
        valueTV.setGravity(Gravity.BOTTOM);
        valueTV.setTextColor(Color.argb(255, 255, 255, 255));
        valueTV.setTextSize(12);
        valueTV.setPadding(10,0,0,0);
        valueTV.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        //user
        TextView usr = new TextView(this);
        usr.setText(jkl.getUser());
        usr.setGravity(Gravity.BOTTOM);
        usr.setTextSize(16);
        usr.setPadding(10,0,0,0);
        usr.setTextColor(Color.argb(255, 255, 255, 255));
        if(al==2){
            usr.setTextColor(Color.argb(255, 0, 255, 0));
        }
        if(al==1){
            usr.setTextColor(Color.argb(255, 255, 0, 0));
        }

        //image
        CircleImageView im23=new CircleImageView(this);
        FirebaseDatabase.getInstance().getReference().child("Users").child(userid).child("dp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Glide.with(getApplicationContext()).load(snapshot.getValue()).into(im23);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        im23.setLayoutParams(new ViewGroup.LayoutParams(70,70));

        //im24
        CircleImageView im24=new CircleImageView(this);
        FrameLayout.LayoutParams myImageLayout = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, 70);
        myImageLayout.gravity=Gravity.RIGHT;
        im24.setLayoutParams(myImageLayout);
        im24.setImageResource(R.drawable.addbtn);

        im24.setId(100+mp1.size());
        mp1.add(jkl);
        im24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int xkl=im24.getId();  xkl-=100;
                FirebaseDatabase.getInstance().getReference().child("Users")
                        .child(jkl.getId())
                        .child("Requests")
                        .push().setValue(new info(user,useremail,userdp,userid));
                Toast.makeText(getApplicationContext(),"Request Sent Successfully",Toast.LENGTH_SHORT).show();
            }
        });

        // new layout
        LinearLayout lte=new LinearLayout(this);
        lte.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        lte.setOrientation(LinearLayout.HORIZONTAL);

        //inner layout
        LinearLayout inlte=new LinearLayout(this);
        inlte.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inlte.setOrientation(LinearLayout.VERTICAL);
        inlte.addView(usr);
        inlte.addView(valueTV);

        //lte arrange;
        lte.addView(im23);
        lte.addView(inlte);
        lte.addView(im24);

        return lte;
    }
}