package com.example.myapplication;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class fbdatabase {
    private DatabaseReference ref;

    public DatabaseReference getRef() {
        return ref;
    }

    public fbdatabase(String f){
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        ref=db.getReference(f);
    }

    public Task<Void> add(datamsg data){
        return ref.push().setValue(data);
    }
    public Task<Void> adduserdata(imgupload data){
        return ref.push().setValue(data);
    }

}
