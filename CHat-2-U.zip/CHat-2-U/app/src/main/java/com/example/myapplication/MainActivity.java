package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    boolean iop;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn=findViewById(R.id.signin); iop=false;

        FirebaseDatabase.getInstance().getReference().child("Information").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot s : snapshot.getChildren()){
                    info jkl=s.getValue(info.class);
                    Usersclass.getInstance().allusersid.put(jkl.getId(),jkl);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        gso=new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        gsc= GoogleSignIn.getClient(getApplicationContext(), gso);

        GoogleSignInAccount account=GoogleSignIn.getLastSignedInAccount(this);
        if(account!=null){
            Usersclass.getInstance().gso=gso;
            Usersclass.getInstance().gsc=gsc;
            Usersclass.getInstance().accinfo=account;

            finish();
            Intent x=new Intent(getApplicationContext(),Menu.class);
            startActivity(x);
        }

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SignIn();
            }
        });
    }

    public void SignIn(){
        Intent x=gsc.getSignInIntent();
        startActivityForResult(x,100);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100){
            Task<GoogleSignInAccount> task=GoogleSignIn.getSignedInAccountFromIntent(data);
            try{
               GoogleSignInAccount xl=task.getResult(ApiException.class);
               String link="https://firebasestorage.googleapis.com/v0/b/chat-2-u.appspot.com/o/18b9ffb2a8a791d50213a9d595c4dd52.jpg?alt=media&token=edcf68ac-2100-4114-91c7-8b272cbeca1b";

               FirebaseDatabase.getInstance().getReference().child("Users").child(xl.getId()).addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                       if(snapshot.exists()){
                           iop=true;
                       }
                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError error) {

                   }
               });

               if(iop==false){
                   FirebaseDatabase.getInstance().getReference().child("Information").push().setValue(new info(xl.getDisplayName(),xl.getEmail(),link,xl.getId()));
               }

               DatabaseReference df=FirebaseDatabase.getInstance().getReference().child("Users")
                               .child(xl.getId().toString());

               df.child("Name").setValue(xl.getDisplayName());
               df.child("Email").setValue(xl.getEmail());
               df.child("dp").setValue(link);

                Usersclass.getInstance().gso=gso;
                Usersclass.getInstance().gsc=gsc;
                Usersclass.getInstance().accinfo=xl;

               finish();
               Intent x=new Intent(getApplicationContext(),Menu.class);
               startActivity(x);
            }catch (ApiException e){
               Toast.makeText(getApplicationContext(),e.toString(),Toast.LENGTH_SHORT).show();
            }
        }
    }
}