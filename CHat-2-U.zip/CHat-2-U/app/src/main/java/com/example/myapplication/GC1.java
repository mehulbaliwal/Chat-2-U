package com.example.myapplication;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.Clock;
import java.util.HashMap;
import java.util.HashSet;

public class GC1 extends AppCompatActivity {
    View linearLayout;
    private String chid="Chat-tu";
    private String server;
    String uid,userid,username;
    TextView asta;
    HashSet<datamsg> st;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gc1);
        if(Settings.System.getInt(getContentResolver(),Settings.System.ACCELEROMETER_ROTATION,0)==1){
            glob.getInstance().var=6;
        }
        st=new HashSet<datamsg>();
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        server=getIntent().getStringExtra("key");
        uid=getIntent().getStringExtra("id");
        asta=(TextView)findViewById(R.id.textView2);
        asta.setText(server);
        userid=Usersclass.getInstance().accinfo.getId();
        glob.getInstance().var=9452;
        RelativeLayout beta=findViewById(R.id.loadingPanel);

        username=Usersclass.getInstance().accinfo.getDisplayName().toString();

        linearLayout =  findViewById(R.id.inter);
        ImageButton btn = findViewById(R.id.imb);
        EditText w = findViewById(R.id.ed);
        GC1 ptr=this;
        //messages(usr,msg,user);
        ScrollView var=findViewById(R.id.scrl);
        ImageButton btn2= findViewById(R.id.dp);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x = new Intent(getApplicationContext(), Profile.class);
                x.putExtra("user",server);
                x.putExtra("id",uid);
                startActivity(x);
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                String m=w.getText().toString();

                if(m.length()>0) {
                    datamsg data=new datamsg(username,m);
                    TextView save=txt(m, 1,username);
                    w.setText("");

                    lastupdate(uid,userid,data,save);
                    lastupdate(userid,uid,data,save);

                    var.post(new Runnable() {
                        public void run() {
                            var.fullScroll(var.FOCUS_DOWN);
                        }
                    });
                }

            }
        });

        DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child("Users").child(userid).child("Friends").child(uid).child("Messages");
        ref.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                datamsg last=new datamsg();
                for(DataSnapshot s : snapshot.getChildren()){
                    last=s.getValue(datamsg.class);
                    if(glob.getInstance().var!=5) {
                        if(!last.getUser().equals(username)){
                            txt(last.getMsg(), 0,last.getUser());
                        }else {
                            txt(last.getMsg(), 2,username);
                        }
                    }
                }

                if(last!=null && !last.getUser().equals(username) && glob.getInstance().var==5) {
                    txt(last.getMsg(), 0,last.getUser());
                }
                  beta.setVisibility(View.GONE);
                var.post(new Runnable() {
                    public void run() {
                        var.fullScroll(var.FOCUS_DOWN);
                    }
                });
                glob.getInstance().var=5;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        com.rw.keyboardlistener.KeyboardUtils.addKeyboardToggleListener(this, new com.rw.keyboardlistener.KeyboardUtils.SoftKeyboardToggleListener()
        {
            @Override
            public void onToggleSoftKeyboard(boolean isVisible) {
                if(isVisible) {
                    var.post(new Runnable() {
                        public void run() {
                            var.fullScroll(var.FOCUS_DOWN);
                        }
                    });
                }
            }
        });

    }



    public TextView txt(String msg,int al,String user){
        //msg
        TextView valueTV = new TextView(this);
        valueTV.setText(msg);
        valueTV.setGravity(Gravity.BOTTOM);
        valueTV.setTypeface(asta.getTypeface());
        valueTV.setTextColor(Color.argb(255, 255, 255, 255));
        valueTV.setTextSize(12);
        valueTV.setPadding(10,0,0,0);
        valueTV.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        //user
        TextView usr = new TextView(this);
        usr.setText(user);
        usr.setGravity(Gravity.BOTTOM);
        usr.setTypeface(asta.getTypeface());
        usr.setTextSize(16);
        usr.setPadding(10,0,0,0);
        usr.setTextColor(Color.argb(255, 255, 255, 255));
        if(al==2){
            usr.setTextColor(Color.argb(255, 0, 255, 0));
        }
        if(al==1){
            usr.setTextColor(Color.argb(255, 255, 0, 0));
        }

        // space
        TextView space = new TextView(this);
        space.setText("");
        space.setTextSize(20);
        space.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        //image
        de.hdodenhof.circleimageview.CircleImageView im23=new de.hdodenhof.circleimageview.CircleImageView(this);
        FirebaseDatabase.getInstance().getReference().child("Users").child(userid).child("dp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Glide.with(getApplicationContext()).load(snapshot.getValue()).into(im23);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        im23.setLayoutParams(new LayoutParams(70,70));

        // new layout
        LinearLayout lte=new LinearLayout(this);
        lte.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));
        lte.setOrientation(LinearLayout.HORIZONTAL);

        //inner layout
        LinearLayout inlte=new LinearLayout(this);
        inlte.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
        inlte.setOrientation(LinearLayout.VERTICAL);
        inlte.addView(usr);
        inlte.addView(valueTV);

        //lte arrange
        lte.addView(im23);
        lte.addView(inlte);

        //arranging
        ((LinearLayout) linearLayout).addView(lte);
        ((LinearLayout) linearLayout).addView(space);
        return usr;
    }

    public void lastupdate(String uid1,String uid2,datamsg m,TextView txt){
        DatabaseReference db=FirebaseDatabase.getInstance().getReference().child("Users")
                .child(uid1).child("Friends")
                .child(uid2);

        db.child("LastMessage").setValue(m).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                txt.setTextColor(Color.argb(255, 0, 255, 0));
            }
        });
        db.child("Messages").push().setValue(m);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
        startActivity(new Intent(getApplicationContext(),Menu.class));
    }
}

