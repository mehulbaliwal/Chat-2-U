package com.example.myapplication;

import static com.example.myapplication.R.drawable.groupicon;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.media.Image;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.ContactsContract;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

public class Menu extends AppCompatActivity {
    LinearLayout lay;
    int height;
    HashMap<String,TextView> mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        int width = size.x;
        height = size.y;

        ImageButton btn= findViewById(R.id.imgbtn23);
        ImageView btn1= findViewById(R.id.imgbtn236);
        String user=Usersclass.getInstance().accinfo.getId().toString();

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),listall.class));
            }
        });

        //Glide.with(this).load(Usersclass.getInstance().users.get(user)).into(btn);
        LinearLayout ltek=findViewById(R.id.ltem);
        // de.hdodenhof.circleimageview.CircleImageView addbtn=findViewById(R.id.imageButton2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Usersclass.getInstance().gsc.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        finishAffinity();
                        new Usersclass().reset();
                        new glob().reset();
                        new reso().reset();
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    }
                });
            }
        });

        Button btn36=findViewById(R.id.btn6964);
        btn36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),reqyests.class));
            }
        });

        lay=findViewById(R.id.ltem);
        mp=new HashMap<String,TextView>();
        FirebaseDatabase.getInstance().getReference().child("Users")
                .child(Usersclass.getInstance().accinfo.getId())
                .child("Friends").addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                         for(DataSnapshot s : snapshot.getChildren()){
                             String kl=s.getKey().toString();

                             FirebaseDatabase.getInstance().getReference().child("Users").child(Usersclass.getInstance().accinfo.getId()).child("Friends").child(kl).child("LastMessage").addValueEventListener(new ValueEventListener() {
                                 @Override
                                 public void onDataChange(@NonNull DataSnapshot snapshot) {
                                     if(mp.containsKey(kl)){
                                         datamsg jk1=snapshot.getValue(datamsg.class);
                                         if(jk1.getUser().equals(Usersclass.getInstance().accinfo.getDisplayName())){
                                             mp.get(kl).setText("You : "+jk1.getMsg());
                                         }else{
                                             mp.get(kl).setText(jk1.getUser()+" : "+jk1.getMsg());
                                         }
                                         return;
                                     }


                                     TextView space = new TextView(getApplicationContext());
                                     space.setText("");
                                     space.setTextSize(20);
                                     space.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                                     lay.addView(space);
                                     lay.addView(add(Usersclass.getInstance().allusersid.get(kl).getUser(),snapshot.getValue(datamsg.class),kl,1));
                                 }

                                 @Override
                                 public void onCancelled(@NonNull DatabaseError error) {

                                 }
                             });

                         }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

    }

    public LinearLayout add(String jk,datamsg jk1,String gh,int al){
        //msg
        TextView valueTV = new TextView(this);
        if(jk1.getUser().equals(Usersclass.getInstance().accinfo.getDisplayName())){
            valueTV.setText("You : "+jk1.getMsg());
        }else{
            valueTV.setText(jk1.getUser()+" : "+jk1.getMsg());
        }

        valueTV.setGravity(Gravity.BOTTOM);
        valueTV.setTextColor(Color.argb(255, 255, 255, 255));
        valueTV.setTextSize(12);
        valueTV.setPadding(10,0,0,0);
        valueTV.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        mp.put(gh,valueTV);
        //user
        TextView usr = new TextView(this);
        usr.setText(jk);
        usr.setGravity(Gravity.BOTTOM);
        usr.setTextSize(16);
        usr.setPadding(10,0,0,0);
        usr.setTextColor(Color.argb(255, 255, 255, 255));
        if(al==2){
            usr.setTextColor(Color.argb(255, 0, 255, 0));
        }
        if(al==1){
            usr.setTextColor(Color.argb(255, 255, 0, 0));
        }

        //image
        CircleImageView im23=new CircleImageView(this);
        FirebaseDatabase.getInstance().getReference().child("Users").child(gh).child("dp").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Glide.with(getApplicationContext()).load(snapshot.getValue()).into(im23);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        im23.setLayoutParams(new ViewGroup.LayoutParams(70,70));

        // new layout
        LinearLayout lte=new LinearLayout(this);
        lte.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        lte.setOrientation(LinearLayout.HORIZONTAL);

        //inner layout
        LinearLayout inlte=new LinearLayout(this);
        inlte.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inlte.setOrientation(LinearLayout.VERTICAL);
        inlte.addView(usr);
        inlte.addView(valueTV);

        //lte arrange;
        lte.addView(im23);
        lte.addView(inlte);
        lte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it=new Intent(getApplicationContext(),GC1.class);
                it.putExtra("key",jk);
                it.putExtra("id",gh);
                startActivity(it);
            }
        });

        return lte;
    }
}