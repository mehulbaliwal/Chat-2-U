package com.example.myapplication;

public class datamsg {
    String user,msg;
    public datamsg(){ user=""; msg=""; }
    public datamsg(String user,String msg){
        this.user=user; this.msg=msg;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
