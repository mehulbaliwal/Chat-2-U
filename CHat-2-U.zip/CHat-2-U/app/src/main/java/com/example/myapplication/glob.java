package com.example.myapplication;

public class glob {
    private static glob mInstance=null;
    public int var;
    public int ast;
    public int var2;
    protected glob(){}
    public static synchronized glob getInstance(){
        if(mInstance==null){
            mInstance=new glob();
        }
        return mInstance;
    }

    public void reset(){
        this.var=-3;
        this.ast=-3;
        this.var2=-3;
    }

}
