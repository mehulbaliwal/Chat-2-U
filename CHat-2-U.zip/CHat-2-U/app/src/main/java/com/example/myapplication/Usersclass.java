package com.example.myapplication;

import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;

import java.util.ArrayList;
import java.util.HashMap;

public class Usersclass {
    private static com.example.myapplication.Usersclass mInstance=null;
    public HashMap<String,String>users;
    public HashMap<String,String>usersid;
    public HashMap <String,ArrayList<String>> servers;
    public HashMap<String,TextView>textset;
    public HashMap<String, ImageView>newset;
    public HashMap<String,info>allusersid;
    public HashMap<String, Long>lmtime;
    public GoogleSignInAccount accinfo;
    public GoogleSignInOptions gso;
    public GoogleSignInClient gsc;
    protected Usersclass(){
        allusersid=new HashMap<String,info>();
        users=new HashMap<String,String>();
        usersid=new HashMap<String,String>();
        servers=new HashMap <String,ArrayList<String>>();
        textset=new HashMap<String, TextView>();
        newset=new HashMap<String, ImageView>();
        lmtime=new HashMap<String, Long>();
    }
    public static synchronized com.example.myapplication.Usersclass getInstance(){
        if(mInstance==null){
            mInstance=new com.example.myapplication.Usersclass();
        }
        return mInstance;
    }

    public void reset(){
        this.allusersid.clear();
        this.accinfo=null;
        this.users.clear();
        this.gsc=null;
        this.gso=null;
        this.lmtime.clear();
        this.newset.clear();
        this.textset.clear();
        this.servers.clear();
        this.usersid.clear();
    }

}
