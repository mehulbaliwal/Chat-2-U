package com.example.myapplication;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.time.Clock;
import java.util.HashMap;

public class GC extends AppCompatActivity {
    View linearLayout;
    private String chid="Chat-tu";
    private String server;
    TextView asta;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gc);
        if(Settings.System.getInt(getContentResolver(),Settings.System.ACCELEROMETER_ROTATION,0)==1){
            glob.getInstance().var=6;
        }

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int width = displayMetrics.widthPixels;
        int height = displayMetrics.heightPixels;
        server=getIntent().getStringExtra("key");
        asta=(TextView)findViewById(R.id.textView2);
        asta.setText(server);
        RelativeLayout beta=findViewById(R.id.loadingPanel);
        //String[] msg={"hi","hello","bonjour","mochhi","ola","hi","hello","bonjour","mochhi","ola","hi","hello","bonjour","mochhi","ola","hi","hello","bonjour","mochhi","ola"};
        //String[] usr={"Anup","Bishesh","Sidcrz","Mehul","Ravi","Anup","Bishesh","Sidcrz","Mehul","Ravi","Anup","Bishesh","Sidcrz","Mehul","Ravi","Anup","Bishesh","Sidcrz","Mehul","Ravi"};
        String user=Usersclass.getInstance().accinfo.getDisplayName();

        linearLayout =  findViewById(R.id.inter);
        ImageButton btn = findViewById(R.id.imb);
        EditText w = findViewById(R.id.ed);
        GC ptr=this;
        //messages(usr,msg,user);
        ScrollView var=findViewById(R.id.scrl);
        ImageButton btn2= findViewById(R.id.dp);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent x = new Intent(getApplicationContext(), Profile.class);
                startActivity(x);
            }
        });

        fbdatabase db=new fbdatabase(server);
        btn.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onClick(View view) {
                String m=w.getText().toString();

                if(m.length()>0) {
                    datamsg data=new datamsg(user,m);
                    TextView save=txt(m, 1,user);
                    w.setText("");
                    db.add(data).addOnSuccessListener(suc->{
                        save.setTextColor(Color.argb(255, 0, 255, 0));
                        LastMessage lms=new LastMessage(user,m, Clock.systemDefaultZone().millis());
                        FirebaseDatabase.getInstance().getReference("LastMsg")
                                .child(server)
                                .setValue(lms);
                    }).addOnFailureListener(er->{
                        save.setText("Network Error!");
                    });
                    var.post(new Runnable() {
                        public void run() {
                            var.fullScroll(var.FOCUS_DOWN);
                        }
                    });
                }

            }
        });

        DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child(server);
        ref.addValueEventListener(new ValueEventListener() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //datamsg out=snapshot.getValue(datamsg.class);
                datamsg last=new datamsg();
                for(DataSnapshot s : snapshot.getChildren()){
                    last=s.getValue(datamsg.class);
                    if(glob.getInstance().var!=5) {
                        if(!last.getUser().equals(user)){
                            txt(last.getMsg(), 0,last.getUser());
                        }else {
                            txt(last.getMsg(), 2,user);
                        }
                    }
                }

                if(last.getUser()!=user && glob.getInstance().var==5) {
                    txt(last.getMsg(), 0,last.getUser());
                }
                beta.setVisibility(View.GONE);
                var.post(new Runnable() {
                    public void run() {
                        var.fullScroll(var.FOCUS_DOWN);
                    }
                });
                glob.getInstance().var=5;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });


        com.rw.keyboardlistener.KeyboardUtils.addKeyboardToggleListener(this, new com.rw.keyboardlistener.KeyboardUtils.SoftKeyboardToggleListener()
        {
            @Override
            public void onToggleSoftKeyboard(boolean isVisible) {
            if(isVisible) {
                var.post(new Runnable() {
                    public void run() {
                        var.fullScroll(var.FOCUS_DOWN);
                    }
                });
            }
            }
        });

    }



    public TextView txt(String msg,int al,String user){
        //msg
        TextView valueTV = new TextView(this);
        valueTV.setText(msg);
        valueTV.setGravity(Gravity.BOTTOM);
        valueTV.setTypeface(asta.getTypeface());
        valueTV.setTextColor(Color.argb(255, 255, 255, 255));
        valueTV.setTextSize(12);
        valueTV.setPadding(10,0,0,0);
        valueTV.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        //user
        TextView usr = new TextView(this);
        usr.setText(user);
        usr.setGravity(Gravity.BOTTOM);
        usr.setTypeface(asta.getTypeface());
        usr.setTextSize(16);
        usr.setPadding(10,0,0,0);
        usr.setTextColor(Color.argb(255, 255, 255, 255));
        if(al==2){
            usr.setTextColor(Color.argb(255, 0, 255, 0));
        }
        if(al==1){
            usr.setTextColor(Color.argb(255, 255, 0, 0));
        }

        // space
        TextView space = new TextView(this);
        space.setText("");
        space.setTextSize(20);
        space.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        //image
        de.hdodenhof.circleimageview.CircleImageView im23=new de.hdodenhof.circleimageview.CircleImageView(this);
        try {
            Glide.with(this).load(Usersclass.getInstance().users.get(user)).into(im23);
        } catch (Exception e){
            Toast.makeText(this,e.toString(),Toast.LENGTH_LONG);
        }
        im23.setLayoutParams(new LayoutParams(70,70));

        // new layout
        LinearLayout lte=new LinearLayout(this);
        lte.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT));
        lte.setOrientation(LinearLayout.HORIZONTAL);

        //inner layout
        LinearLayout inlte=new LinearLayout(this);
        inlte.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
        inlte.setOrientation(LinearLayout.VERTICAL);
        inlte.addView(usr);
        inlte.addView(valueTV);

        //lte arrange
        lte.addView(im23);
        lte.addView(inlte);

        //arranging
        ((LinearLayout) linearLayout).addView(lte);
        ((LinearLayout) linearLayout).addView(space);
        return usr;
    }

    @Override
    public void onBackPressed() {
        Usersclass.getInstance().newset.get(server).setLayoutParams(new LayoutParams(0,0));
        super.onBackPressed();
    }
}

