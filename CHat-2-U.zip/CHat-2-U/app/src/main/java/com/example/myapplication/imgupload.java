package com.example.myapplication;

import java.util.ArrayList;

public class imgupload {
    public imgupload(ArrayList<String> servers, String user, String dp) {
        this.servers = servers;
        this.user = user;
        this.dp = dp;
    }

    public ArrayList<String> getServers() {
        return servers;
    }

    public void setServers(ArrayList<String> servers) {
        this.servers = servers;
    }

    ArrayList<String> servers;

    String user,dp;
    public imgupload(){}


    public String getDp() {
        return dp;
    }

    public void setDp(String dp) {
        this.dp = dp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
